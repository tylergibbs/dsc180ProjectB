import testing_one

testing_one.test_all_methods(output_dir='testing02.jsonl')