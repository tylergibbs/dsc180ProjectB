from GOLEMTS.model import GolemTS
import GOLEMTS.trainer as golem_trainer

def run_DYNOTEARS():
    pass

def run_GOLEMTS(n, d, p, Y, lambda_1=0.1, lambda_2=1, A_init=None, ev=True, lr=3e-3, lambda_3=9,
               epochs=10_000, warmup_epochs=0, log=False, device=None):
    model = GolemTS(n=n, d=d, p=p, Y=Y, device=device, 
                lambda_1=lambda_1, lambda_2=lambda_2, A_init=A_init, ev=True, lr=lr, lambda_3=lambda_3)

    likes, evs = golem_trainer.train(model, Y, epochs=epochs, warmup_epochs=warmup_epochs, log=log, device=device)

    model_B = model.B.detach().numpy()
    model_B[np.abs(model_B) < 0.2] = 0
    model_A = model_B[:, :Y.shape[1]]

    np.fill_diagonal(model_A, 0)

    return model_A


def run_DAGMATS():
    pass
