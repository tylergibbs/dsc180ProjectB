import argparse
from report.snp100 import snp100


def clean():
    subprocess.run(['rm', 'output/*'], stdout = sys.stdout, check=True, text=True)


def get_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('cmd', choices=commands.keys())

    return parser.parse_args()

def all():
    """Dynamicaly gets and runs all comands in comands"""
    for k in commands:
        if (k != 'all'):
           print("running:{}".format(k))
           commands[k]()


commands = {
'all': all,
'snp100':snp100

}

def run():
    parser = get_args()

    cmd = parser.cmd
    print(cmd)
    commands[cmd]()



if __name__ == '__main__':
   run()
