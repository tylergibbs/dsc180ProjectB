
# Introduction 

## Causal Analisys

### Relevance 

### History

### Numerical Optimisation

## DYNOTEARS

## GOLEM

## DAGMA

# Metrics

## Synthetic Data

### Replication

### Timeseries vs Asymictric

## Real World Data

### Genetic data

### Stock Market

### Predictive Analisys

# Usage

## Run your own

## Examples 
